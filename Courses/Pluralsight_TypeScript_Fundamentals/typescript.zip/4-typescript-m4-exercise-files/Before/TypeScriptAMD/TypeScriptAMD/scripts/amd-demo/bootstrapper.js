/// <reference path="alerter.ts" />
var alerter = new Alerter();
alerter.showMessage();
//# sourceMappingURL=bootstrapper.js.map