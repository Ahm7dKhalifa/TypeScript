/// <reference path="alerter.ts" />

var alerter = new Alerter();

alerter.showMessage();