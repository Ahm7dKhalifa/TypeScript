;
var DataService = (function () {
    function DataService() {
        this.msg = 'Welcome to the Show!';
    }
    DataService.prototype.getMessage = function () { return this.msg; };
    return DataService;
})();
//# sourceMappingURL=04-05-dataservice.js.map