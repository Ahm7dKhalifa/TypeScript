/// <reference path="04-05-alerter.ts" />

var alerter = new Alerter();

alerter.showMessage();